let accounts = [{
    "id": 1,
    "username": "Manik Pillai",
    "email": "manik_pillai@schroeder.info",
    "gender": "Female",
    "status": "Inactive"
},
{
    "id": 2,
    "username": "Kumari Tandon",
    "email": "tandon_kumari@howel-hermiston.biz",
    "gender": "Male",
    "status": "active"
},
{
    "id": 3,
    "username": "Baijayanti Mehrotra",
    "email": "baijayanti_mehrontra@heaney.io",
    "gender": "Male",
    "status": "Inactive"
},
{
    "id": 4,
    "username": "Jagadish Adiga",
    "email": "jagadish_adiga@wintheiser.info",
    "gender": "Female",
    "status": "Inactive"
},
{
    "id": 5,
    "username": "Raj Butt",
    "email": "butt_raj@langosh.co",
    "gender": "Male",
    "status": "Inactive"
},

];

module.exports = accounts;